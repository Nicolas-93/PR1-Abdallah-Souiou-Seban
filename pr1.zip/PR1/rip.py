
def gen_dico_coups_possibles(k):
    """
    Initialise un dictionnaire associant les coups
    possibles à un booléen indiquant True, (qui sera
    modifié afin d'indiquer si le coup associé pourra être
    utilisé)

    :param k int: Nombre d'allumettes que pourra tirer un joueur
    """
    return {coup: True for coup in range(1, k)}


def coup_possible(liste_allumettes: List[Allumette], k_coups_possibles: Dict) -> bool:
    """
    Retourne ``True`` si le prochain joueur pourra prélever une allumette.

    :param list liste_allumettes: liste d'objets allumettes
    :param dict k_coups_possibles: Dictionnaire contenant les
    """

    nombre_allumettes_actuel = len(liste_allumettes)
    
    for key, value in k_coups_possibles:
        if value:
            if key <= nombre_allumettes_actuel:
                return True
    return False


k_coups_possibles = gen_dico_coups_possibles(k)


def initialiser_allumettes(nb_rangees=5) -> List[Allumette]: # Sans support du jeu de marienbad
    """
    Initialise une liste d'objets ``Allumette``, dont les coordonnées
    ont été adaptées à la taille de la fenêtre par leurs constantes globales
    """
    
    liste_allumettes = []
    marge = 0

    espacement_x = largeur_fenetre / (nombre_allumettes+1) - marge
    x_max = (nombre_allumettes-1) * espacement_x + largeur_allumette  #nombre_allumettes * espacement - espacement/2
    x_centre = (largeur_fenetre - x_max)/2
    
    espacement_y = hauteur_fenetre / (nb_rangees) - marge
    y_max = (nb_rangees-1) * espacement_y + hauteur_fenetre
    y_centre = (hauteur_fenetre - y_max)/2 + (hauteur_fenetre - hauteur_allumette)/2
    
    for j in range(0, nb_rangees):
        #(hauteur_fenetre / (nb_rangees))/2
        ligne_allumettes = []
        for i in range(0, nombre_allumettes):
            ligne_allumettes.append(
                Allumette(
                    ax = i * espacement_x + x_centre,
                    ay = j * espacement_y + y_centre,
                    bx = i * espacement_x + x_centre + largeur_allumette,
                    by = j * espacement_y + y_centre + hauteur_allumette
                )
            )
        liste_allumettes.append(ligne_allumettes)

    return liste_allumettes


def initialiser_allumettes(liste_marienbad=[1,3,5]) -> List[Allumette]: # Avec support du jeu de marienbad
    """
    Initialise une liste d'objets ``Allumette``, dont les coordonnées
    ont été adaptées à la taille de la fenêtre par leurs constantes globales
    """
    
    liste_allumettes = []
    nb_rangees = len(liste_marienbad)
    nombre_allumettes_max = max(liste_marienbad)
    marge = 0

    espacement_x = largeur_fenetre / (nombre_allumettes_max+1) - marge
    x_max = (nombre_allumettes_max-1) * espacement_x + largeur_allumette  #nombre_allumettes * espacement - espacement/2
    x_centre = (largeur_fenetre - x_max)/2
    
    espacement_y = hauteur_fenetre / (nb_rangees) - marge
    y_max = (nb_rangees-1) * espacement_y + hauteur_fenetre
    y_centre = (hauteur_fenetre - y_max)/2 + (hauteur_fenetre - hauteur_allumette)/2
    
    for j in range(0, nb_rangees):
        #(hauteur_fenetre / (nb_rangees))/2
        ligne_allumettes = []
        for i in range(0, liste_marienbad[j]):
            ligne_allumettes.append(
                Allumette(
                    ax = i * espacement_x + x_centre,
                    ay = j * espacement_y + y_centre,
                    bx = i * espacement_x + x_centre + largeur_allumette,
                    by = j * espacement_y + y_centre + hauteur_allumette
                )
            )
        liste_allumettes.append(ligne_allumettes)

    return liste_allumettes


def dessiner_allumettes(liste_allumettes: List[Allumette]): # Avec support du jeu de marienbad
    """
    Dessines les allumettes de la liste.

    :param liste_allumettes: Liste d'objets ``Allumette``
    """
    for ligne_allumette in liste_allumettes:
        for allumette in ligne_allumette:
            dessin_allumette(allumette, 1)


def centrer_boutons(liste_boutons: List[Bouton], marge=25):
    """
    Centres les boutons de la ``liste_boutons`` par rapport à la fenêtre,
    et adapte la largeur du rectangle formant le bouton, par rapport
    à la taille maximale du texte d'un bouton.
    Utilise la variable globale ``largeur_fenetre``.

    :param list liste_boutons: Liste d'objets ``Bouton``s
    :param float marge: Marge à ajouter entre le texte et le rectangle
    """
    
    longueur_max = texte_longueur_max(liste_boutons)    
    largeur_bouton = longueur_max + marge*2

    # taille_texte_optimise = taille_texte_bouton(liste_boutons[1], largeur_bouton)

    for bouton in liste_boutons:
        bouton.ax = (cfg.largeur_fenetre-largeur_bouton)/2
        bouton.bx = cfg.largeur_fenetre - bouton.ax
        #bouton.taille_texte = taille_texte_optimise 


def taille_texte_bouton(bouton: Bouton, largeur_bouton, marge=0):

    hauteur_bouton = bouton.by - bouton.ay
    taille_texte = 1

    while fltk.taille_texte:
        taille_texte += 1

    return taille_texte - 1


def texte_longueur_max(liste_boutons: List[Bouton]) -> float:

    longueur_max = -1
    for bouton in liste_boutons:
        longueur = longueur_texte(bouton)
        if longueur > longueur_max:
            longueur_max = longueur

    return longueur_max

def longueur_texte(bouton: Bouton):
    """
    Renvoie la longueur de le chaine en pixels

    :param Bouton bouton: Objet Bouton  
    """
    return fltk.taille_texte(bouton.texte, bouton.police, bouton.taille_texte)[0]


def hauteur_texte(bouton: Bouton, taille: int):
    """
    Retourne la hauteur maximale d'une police à l'aide d'une chaîne de test (N'utilise
    pas le texte du bouton)
    """
    chaine_test = 'ÉABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxy'
    return fltk.taille_texte(chaine_test, bouton.police, taille)[1]

def ajuster_texte_boutons(liste_boutons: List[Bouton]):
    
    taille_texte = taille_texte_bouton(liste_boutons[0], 0)
    for bouton in liste_boutons:
        bouton.taille_texte = taille_texte




def ouvrir_image(fichier):
    """
    Ouvre l'image contenue dans ``fichier``, et retourne
    un objet image

    :param str fichier: nom du fichier contenant l'image
    :return: Objet image
    """

    if PIL_AVAILABLE:
        img = Image.open(fichier)
        tkimage = ImageTk.PhotoImage(img)
        # Image.load(tkimage)
    else:
        tkimage = tk.PhotoImage(file=fichier)

    return tkimage


def redimensionner_image(taille: tuple, fichier, coeff:float,
                         reechantillonage=None):
    """
    Ouvre une image et la redimensionne à la taille indiquée par le tuple
    ``(largeur, hauteur)``, il est également possible d'appliquer
    un filtre de réchantillonage pour améliorer le rendu du redimensionnement:
    PIL.Image.NEAREST, PIL.Image.BOX, PIL.Image.BILINEAR, PIL.Image.HAMMING,
    PIL.Image.BICUBIC or PIL.Image.LANCZOS

    :param tuple taille: Couple (largeur, hauteur) représentant la taille redimenssionée
    :param fichier: Fichier de l'image à redimensioner
    :return: Objet image
    """
    if PIL_AVAILABLE:
        with Image.open(fichier) as img:
            return ImageTk.PhotoImage(img.resize(taille, reechantillonage))
    else:
        PILError()
        return None


def dessin_allumette(Allumette: Allumette, image_allumette):
    """
    Dessine une allumette

    :param Allumette: Objet ``Allumette``
    """

    fltk.rectangle(
        Allumette.ax, Allumette.ay,
        Allumette.bx, Allumette.by,
        '#D4AF37', '#D4AF37'
    )
    fltk.cercle(
        Allumette.ax+(cfg.largeur_allumette/2), Allumette.ay+cfg.rayon_cercle_allumette-1,
        cfg.rayon_cercle_allumette,
        'red', 'red'
    )
    pass


def initialiser_allumettes() -> List[Allumette]:
    """
    Initialise une liste d'objets ``Allumette``, dont les coordonnées
    ont été adaptées à la taille de la fenêtre par leurs constantes globales
    """

    liste_allumettes = []
    marge = 10
    espacement = (cfg.largeur_fenetre - cfg.nombre_allumettes * cfg.largeur_allumette) / cfg.nombre_allumettes
    x_max = cfg.nombre_allumettes*cfg.largeur_allumette + (cfg.nombre_allumettes - 1)*espacement
    
    #x_max = cfg.nombre_allumettes * espacement #- espacement/2
    centre = (cfg.largeur_fenetre - x_max)/2

    print("espacement: ", espacement, "x_max: ", x_max, "centre: ", centre)

    for i in range(cfg.nombre_allumettes):
        liste_allumettes.append(
            Allumette(
                ax = i + espacement + centre,
                ay = cfg.hauteur_fenetre/2 - cfg.hauteur_allumette/2,
                bx = i + espacement + centre + cfg.largeur_allumette,
                by = cfg.hauteur_fenetre/2 + cfg.hauteur_allumette/2
            )
        )
    
    return liste_allumettes





"""def find_all_indexes(pattern, chaine):
    import re
    return [m.start() for m in re.finditer(pattern, chaine)]"""




    survole = curseur_sur_bouton(bouton)
    if type(bouton) == BoutonBooleen:
        if survole:
            if bouton.etat:
                remplissage = bouton.couleur_hovered_actif
            else:
                remplissage = bouton.couleur_hovered_desactive
        else:
            if bouton.etat:
                remplissage = bouton.couleur_actif
            else:
                remplissage = bouton.couleur_desactive
    else:
        if survole and bouton.enable_hovered:
            remplissage = bouton.couleur_hovered
        else:
            remplissage = bouton.couleur_fond




def selectionCoups(selection, indice, coups_possibles, liste_allumettes, rangee):
    
    if ((selection + indice) > (len(coups_possibles) - 1) or (selection + indice) < 0
    and coups_possibles[selection] >= len(liste_allumettes[rangee])):
        selection2 = selection

    else:
        selection2 = selection + indice

    graphiques.encadre(liste_allumettes, selection2, coups_possibles, rangee)



            if nom_bouton != None and nom_bouton.isnumeric():
                rangee_actuelle = int(nom_bouton)
                if clic_rangee_precedent != rangee_actuelle:
                    clic_rangee_precedent = rangee_actuelle
                    gameplay.reset_selection_rangee(liste_allumettes[clic_rangee_precedent])
                    indice_coups_possibles = -1




def encadre(nombre_allumettes_a_selectionner: int, liste_allumettes: List[Allumette], rangee):
    """
    Détermine la valeur de la propriété ``selection`` des allumettes de la liste, en fonction de
    la selection et des coups possibles
    """

    if nombre_allumettes_a_selectionner == 0:
        liste_allumettes[rangee][-1].selection = False
        return None

    for i in range(len(liste_allumettes[rangee])):
        if i <= nombre_allumettes_a_selectionner:
            liste_allumettes[rangee][-i].selection = True
        else:
            liste_allumettes[rangee][-i].selection = False

        if nombre_allumettes_a_selectionner and (len(liste_allumettes[rangee]) != 1):
            liste_allumettes[rangee][0].selection = False

        else:
            liste_allumettes[rangee][-i].selection = True



def selection_possible(liste_allumettes, selection, coups_possibles, rangee):
    """
    Détermine si la selection demandée est réalisable

    :param list liste_allumettes: Liste d'objets Allumettes
    """

    return coups_possibles[selection] < len(liste_allumettes[rangee])


                raise KeyError(f"L'argument {arg} n'est pas approprié pour un bouton de type {type(bouton)}")



        if len(liste_allumettes[rangee]) == 0:
            del liste_allumettes[rangee]
            for i in range(len(liste_boutons_jeu)):
                if liste_boutons_jeu[i].identificateur == int(rangee):
                    del liste_boutons_jeu[i]
                    break