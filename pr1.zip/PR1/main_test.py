import fltk
import graphiques
import gameplay
from typing import List, Iterable, Optional
from dataclasses import dataclass

@dataclass
class Allumette:
    ax: float
    ay: float
    bx: float
    by: float

# Effet de disparition des allumettes: les allumer!!
# Ajuster/Zoomer les allumettes de manière à optimiser l'espace disponible
# S'accorder à comment séparer les fonction ET "rendre" global certaines constantes
# Mettre un beau message en cas de valeurs incohérentes (minimum 30 pages) :) + message en cas de Ctrl-C ;)
# Gérer le mode misère/normal
# Mode joueur solo

largeur_fenetre, hauteur_fenetre =  500, 500
nombre_allumettes = 10
largeur_allumette, hauteur_allumette = 5, 30 # Adapter la hauteur de l'allumette en fonction des rangées
rayon_cercle_allumette = largeur_allumette*0.65
k = 5
selection = 0


def gen_lst_coup_possibles(k: int) -> list:
    """
    Initialise une liste de valeurs allant de 1 à ``k`` inclu, afin
    de déterminer les coups/tirages possibles.

    :param k int: Nombre d'allumettes que pourra tirer un joueur (k > 0)
    :return set: liste de coups

    >>> gen_set_coup_possibles(8)
    [1, 2, 3, 4, 5, 6, 7, 8]
    >>> gen_set_coup_possibles(1)
    [1]
    """
    return [x for x in range(1, k+1)]


def coup_possible(liste_allumettes: List[Allumette], k_coups_possibles: list, misere=True) -> bool:
    """
    Retourne ``True`` si le prochain joueur pourra prélever une allumette.

    :param list liste_allumettes: liste d'objets allumettes
    :param dict k_coups_possibles: Dictionnaire contenant les

    >>> coup_possible([1, 1, 1, 1, 1], [1,2,3,4])
    True
    >>> coup_possible([0,0,0,0], [4])
    True
    >>> coup_possible([0,0,0,0], [5])
    False
    >>> coup_possible([], [1,2,3,4])
    False
    """

    for coup in k_coups_possibles:
        if coup <= len(liste_allumettes):
            return True
    return False

def initialiser_allumettes(liste_marienbad=[1,3,5,7, 10, 22], marge_bas=hauteur_fenetre*0.05) -> List[Allumette]: # Avec support du jeu de marienbad
    """
    Initialise une liste d'objets ``Allumette``, dont les coordonnées
    ont été adaptées à la taille de la fenêtre par leurs constantes globales
    """
    
    liste_allumettes = []
    nb_rangees = len(liste_marienbad)
    nombre_allumettes_max = max(liste_marienbad)
    marge = marge_bas

    espacement_x = largeur_fenetre / (nombre_allumettes_max+1) #- marge
    x_max = (nombre_allumettes_max-1) * espacement_x + largeur_allumette  #nombre_allumettes * espacement - espacement/2
    x_centre = (largeur_fenetre - x_max)/2
    
    espacement_y = hauteur_fenetre / (nb_rangees) - marge
    y_max = (nb_rangees-1) * espacement_y + hauteur_fenetre
    y_centre = (hauteur_fenetre - y_max)/2 + (hauteur_fenetre - hauteur_allumette)/2
    
    for j in range(0, nb_rangees):
        #(hauteur_fenetre / (nb_rangees))/2
        ligne_allumettes = []
        for i in range(0, liste_marienbad[j]):
            ligne_allumettes.append(
                Allumette(
                    ax = i * espacement_x + x_centre,
                    ay = j * espacement_y + y_centre,
                    bx = i * espacement_x + x_centre + largeur_allumette,
                    by = j * espacement_y + y_centre + hauteur_allumette
                )
            )
        liste_allumettes.append(ligne_allumettes)

    return liste_allumettes


def dessin_allumette(Allumette: Allumette, zoom: float):
    """
    Dessine une allumette

    :param Allumette: Objet ``Allumette``
    :param coeff: *Under Construction...*
    """

    fltk.rectangle(
        Allumette.ax+zoom, Allumette.ay+zoom,
        Allumette.bx-zoom, Allumette.by-zoom,
        '#D4AF37', '#D4AF37'
    )
    fltk.cercle(
        Allumette.ax+(largeur_allumette/2), Allumette.ay,
        rayon_cercle_allumette-zoom,
        'red', 'red'
    )


def dessiner_allumettes(liste_allumettes: List[Allumette]): # Avec support du jeu de marienbad
    """
    Dessines les allumettes de la liste.

    :param liste_allumettes: Liste d'objets ``Allumette``
    """
    for ligne_allumette in liste_allumettes:
        for allumette in ligne_allumette:
            dessin_allumette(allumette, 1)

def fin():
    """
    Scène de fin de jeu
    """
    print("Le prochain joueur ne pourra pas jouer")
    exit(0)
    #fltk.ferme_fenetre()


if __name__ == "__main__":
    
    # coup_possibles = gen_set_coup_possibles(k)
    coup_possibles = [2,4,5] 
    liste_allumettes = initialiser_allumettes()

    fltk.cree_fenetre(largeur_fenetre, hauteur_fenetre)
    while True:
        try:
            fltk.efface_tout()
            # Gestion des événements
            ev = fltk.donne_ev()
            tev = fltk.type_ev(ev)

            if tev == 'Quitte':
                fltk.ferme_fenetre()
                exit()

            elif tev == "ClicGauche":
                if fltk.ordonnee_souris() >= 250 and fltk.ordonnee_souris() <= 350:
                    selection = gameplay.selectionCoups(selection, 1, coup_possibles)
                    
                
                if fltk.ordonnee_souris() < 250:
                    gameplay.jouer_tour(selection, liste_allumettes, coup_possibles)
                    selection = 0
            
            elif tev == "ClicDroit":
                if fltk.ordonnee_souris() >= 250 and fltk.ordonnee_souris() <= 350:
                    selection = gameplay.selectionCoups(selection, -1, coup_possibles)
                print(fltk.abscisse(ev), fltk.ordonnee(ev))

            # fltk.rectangle(0, 0, largeur_fenetre, hauteur_fenetre, couleur='black', remplissage='black')
            dessiner_allumettes(liste_allumettes)
            if not coup_possible(liste_allumettes, coup_possibles):
                fin()

            graphiques.encadre(liste_allumettes, selection, coup_possibles)

            
            
            fltk.mise_a_jour()

        except KeyboardInterrupt:
            print("\nVous devriez pouvoir fermer la fenêtre avec la croix",
                  "théoriquement...",
                  "\nMais merci d'y avoir pris plaisir!! A bientôt!!")
            break


