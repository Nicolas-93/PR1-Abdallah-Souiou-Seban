import fltk

largeur_allumette = 10
hauteur_allumette = 150

def allumette(ax, ay):
    fltk.rectangle(
        ax, ay,
        ax+largeur_allumette, ay+hauteur_allumette,
        remplissage='yellow'
    )
    fltk.cercle(
        ax+largeur_allumette/2, ay,
        largeur_allumette/2+5,
        remplissage='red'
    )

fltk.cree_fenetre(200,200)
allumette(10,10)
fltk.mise_a_jour

